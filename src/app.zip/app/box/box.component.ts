import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-box',
    templateUrl: './box.component.html',
    styleUrls: ['./box.component.css']
})
export class BoxComponent implements OnInit {

    positionX = 50;
    positionY = 50;
    md = 0;

    mouseDown(event) {
        console.log(event.buttons);
        console.log(event);
        this.md = event.buttons;
        if (this.md === 1) {
            console.log(event);
            this.positionX = event.clientX;
            this.positionY = event.clientY;
        }


    }

    constructor() {

    }

    ngOnInit() {
    }

}
